export declare const NAMED_COLORS: Record<string, number>;
//# sourceMappingURL=consts.d.ts.map