import { type LayoutChangeEvent } from 'react-native';
import { type CanvasRef, type RNCanvasContext } from 'react-native-webgpu';
import { type WorkletRuntime } from 'react-native-worklets';
type GPUResources = {
    device: GPUDevice;
    context: RNCanvasContext;
    presentationFormat: GPUTextureFormat;
};
type WGPUSetupResult = {
    canvasRef: React.RefObject<CanvasRef>;
    runtime: WorkletRuntime;
    resources: GPUResources | null;
    /** Wire to `<Canvas onLayout>` so the surface resizes on rotation/layout change. */
    onCanvasLayout: (event: LayoutChangeEvent) => void;
};
export declare function useWGPUSetup(): WGPUSetupResult;
export {};
//# sourceMappingURL=useWGPUSetup.d.ts.map