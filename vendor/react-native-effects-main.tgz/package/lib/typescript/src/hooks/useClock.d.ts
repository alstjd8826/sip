import { type SharedValue } from 'react-native-reanimated';
export declare function useClock(): SharedValue<number>;
//# sourceMappingURL=useClock.d.ts.map