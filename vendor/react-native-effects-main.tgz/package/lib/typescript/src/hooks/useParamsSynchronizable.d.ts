import type { ParamsSynchronizable } from '../components/ShaderView/types';
/**
 * Creates a {@link ParamsSynchronizable} — a live float channel written into
 * the `u.live` / `u.liveData` slots of a {@link ShaderView} every frame. It has
 * its own uniform region, so it leaves all 8 static `params` untouched.
 *
 * The returned `setParamsSynchronizable` runs on the JS thread (call it from gesture or scroll
 * handlers); the values are read by the off-thread render loop. By convention
 * the first four floats carry `(x, y, active, extra)` for pointer input, or
 * `(progress, ...)` for scroll-driven effects — but the meaning is up to the
 * shader consuming `u.live`.
 *
 * Pass `initial` to seed the channel's starting value (read once on first
 * render), so the shader has a sane resting state before the first update —
 * e.g. `[0.5, 0.5, 0, 0]` to start a pointer at screen center. Defaults to all
 * zeros.
 *
 * The channel's length is fixed at the length of `initial` (min 4, max
 * {@link LIVE_FLOAT_COUNT}). The first 4 floats land in `u.live`; floats 4+
 * fill `u.liveData` vec4-by-vec4 — seed a longer `initial` for trail /
 * multi-point effects. `setParamsSynchronizable` replaces the whole channel:
 * slots beyond the values provided reset to 0.
 */
export declare function useParamsSynchronizable(initial?: readonly number[]): {
    paramsSynchronizable: ParamsSynchronizable;
    setParamsSynchronizable: (...values: number[]) => void;
};
//# sourceMappingURL=useParamsSynchronizable.d.ts.map