/**
 * Extra live-data region after `live`: vec4s for paramsSynchronizable channels
 * longer than 4 floats (touch trails, multi-touch, audio spectra).
 */
export declare const LIVE_DATA_VEC4_COUNT = 96;
/** 1648 bytes = (7 + 96) × vec4<f32> */
export declare const UNIFORM_BUFFER_SIZE: number;
/** Number of float32 values in the uniform buffer */
export declare const UNIFORM_FLOAT_COUNT: number;
/** Max floats a paramsSynchronizable channel can carry (`live` + `liveData`). */
export declare const LIVE_FLOAT_COUNT: number;
export declare const UNIFORMS_WGSL = "\nstruct Uniforms {\n  resolution: vec4<f32>,  // (width, height, aspect, pixelRatio)\n  time:       vec4<f32>,  // (seconds, dt, 0, 0)\n  color0:     vec4<f32>,  // colors[0] RGBA\n  color1:     vec4<f32>,  // colors[1] RGBA\n  params0:    vec4<f32>,  // params[0..3]\n  params1:    vec4<f32>,  // params[4..7]\n  live:       vec4<f32>,  // paramsSynchronizable[0..3]; (0,0,0,0) when unused\n  liveData:   array<vec4<f32>, 96>,  // paramsSynchronizable[4..387] for long channels\n};\n@group(0) @binding(0) var<uniform> u: Uniforms;\n";
//# sourceMappingURL=uniforms.d.ts.map