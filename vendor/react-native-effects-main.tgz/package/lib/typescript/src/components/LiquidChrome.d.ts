import type { ViewProps } from 'react-native';
import type { ColorInput } from '../utils/colors';
type Props = ViewProps & {
    /** The base color for the liquid chrome effect. */
    color?: ColorInput;
    /** Animation speed multiplier. Default: 0.2 */
    speed?: number;
    /** Amplitude of the distortion. Default: 0.3 */
    amplitude?: number;
    /** Horizontal frequency. Default: 3 */
    frequencyX?: number;
    /** Vertical frequency. Default: 3 */
    frequencyY?: number;
};
export default function LiquidChrome({ color, speed, amplitude, frequencyX, frequencyY, ...viewProps }: Props): import("react").JSX.Element;
export {};
//# sourceMappingURL=LiquidChrome.d.ts.map