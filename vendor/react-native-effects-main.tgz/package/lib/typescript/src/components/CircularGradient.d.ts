import type { ViewProps } from 'react-native';
import type { ColorInput } from '../utils/colors';
type Props = ViewProps & {
    /** The color at the center of the gradient. */
    centerColor: ColorInput;
    /** The color at the edge of the gradient. Default: transparent */
    edgeColor?: ColorInput;
    /** Horizontal center position (0-1). Default: 0.5 */
    centerX?: number;
    /** Vertical center position (0-1). Default: 0.5 */
    centerY?: number;
    /** Horizontal radius. Default: 0.5 */
    sizeX?: number;
    /** Vertical radius. Default: 0.5 */
    sizeY?: number;
};
export default function CircularGradient({ centerColor, edgeColor, centerX, centerY, sizeX, sizeY, ...viewProps }: Props): import("react").JSX.Element;
export {};
//# sourceMappingURL=CircularGradient.d.ts.map