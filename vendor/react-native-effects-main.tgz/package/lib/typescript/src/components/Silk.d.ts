import type { ViewProps } from 'react-native';
import type { ColorInput } from '../utils/colors';
type Props = ViewProps & {
    /** The base color for the silk effect. */
    color?: ColorInput;
    /** Animation speed multiplier. Default: 1.0 */
    speed?: number;
    /** Scale of the pattern. Default: 1.0 */
    scale?: number;
    /** Rotation angle in radians. Default: 0.0 */
    rotation?: number;
    /** Intensity of the noise grain. Default: 1.5 */
    noiseIntensity?: number;
};
export default function Silk({ color, speed, scale, rotation, noiseIntensity, ...viewProps }: Props): import("react").JSX.Element;
export {};
//# sourceMappingURL=Silk.d.ts.map