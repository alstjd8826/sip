import type { ViewProps } from 'react-native';
import type { ColorInput } from '../utils/colors';
type Props = ViewProps & {
    /** The color tint for the calico swirl effect. */
    color?: ColorInput;
    /** Animation speed multiplier. Default: 1.0 */
    speed?: number;
    /** Intensity of the effect. Default: 1.0 */
    intensity?: number;
};
export default function CalicoSwirl({ color, speed, intensity, ...viewProps }: Props): import("react").JSX.Element;
export {};
//# sourceMappingURL=CalicoSwirl.d.ts.map