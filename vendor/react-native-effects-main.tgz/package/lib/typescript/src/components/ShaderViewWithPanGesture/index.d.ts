import type { ShaderViewProps } from '../ShaderView/types';
/**
 * A {@link ShaderView} that feeds touch input into the shader's `u.live`:
 *
 *   - `live.x` → pointer X, normalized 0..1 (left → right)
 *   - `live.y` → pointer Y, normalized 0..1 (bottom → top, matching UV space)
 *   - `live.z` → 1.0 while touching, 0.0 when released
 *   - `live.w` → 0.0 (reserved)
 *
 * Dragging moves the pointer **relatively** — it pushes from where the pointer
 * already is rather than jumping under the finger — and a fling lets it glide to
 * a stop. The position is **remembered**: it stays wherever it ended and is
 * never reset; only the "touched" flag (`live.z`) toggles on release. A
 * shader can read `live.xy` as a stable resting position and use `live.z`
 * purely for touch-driven emphasis, so the effect never snaps back.
 *
 * The resting value before the first touch is `[0, 0, 0, 0]` by default; pass
 * `initialParamsSynchronizable` to seed it — e.g. `[0.5, 0.5, 0, 0]` to start a
 * pointer at screen center.
 *
 * The drag runs as a **worklet on the UI thread** and writes the synchronizable
 * directly, so pointer updates never hop to the JS thread — matching the rest of
 * the library, which renders off the JS thread. The render runtime reads the
 * same synchronizable each frame.
 */
export type ShaderViewWithPanGestureProps = Omit<ShaderViewProps, 'paramsSynchronizable'> & {
    /**
     * Initial value for the gesture channel (`u.live`) before the first touch.
     * Defaults to `[0, 0, 0, 0]`. Use e.g. `[0.5, 0.5, 0, 0]` to rest a pointer at
     * screen center.
     */
    initialParamsSynchronizable?: readonly [number, number, number, number];
};
export default function ShaderViewWithPanGesture({ style, initialParamsSynchronizable, ...props }: ShaderViewWithPanGestureProps): import("react").JSX.Element;
//# sourceMappingURL=index.d.ts.map