import type { ViewProps } from 'react-native';
import type { ColorInput } from '../utils/colors';
type Props = ViewProps & {
    /** The color tint for the fire effect. */
    color?: ColorInput;
    /** Animation speed multiplier. Default: 1.0 */
    speed?: number;
    /** Size of the sparks. Default: 1.0 */
    sparkSize?: number;
    /** Intensity of the fire. Default: 1.0 */
    fireIntensity?: number;
    /** Intensity of the smoke. Default: 1.0 */
    smokeIntensity?: number;
};
export default function Campfire({ color, speed, sparkSize, fireIntensity, smokeIntensity, ...viewProps }: Props): import("react").JSX.Element;
export {};
//# sourceMappingURL=Campfire.d.ts.map