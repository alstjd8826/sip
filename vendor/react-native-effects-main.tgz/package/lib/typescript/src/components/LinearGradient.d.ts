import type { ViewProps } from 'react-native';
import type { ColorInput } from '../utils/colors';
type Props = ViewProps & {
    /** The color of the start of the gradient. */
    startColor: ColorInput;
    /** The color of the end of the gradient. */
    endColor: ColorInput;
    /** The angle of the gradient in degrees (0-360). */
    angle: number;
    /** Rotation speed in degrees/second. 0 = static. Default: 0 */
    speed?: number;
};
export default function LinearGradient({ startColor, endColor, angle, speed, ...viewProps }: Props): import("react").JSX.Element;
export {};
//# sourceMappingURL=LinearGradient.d.ts.map