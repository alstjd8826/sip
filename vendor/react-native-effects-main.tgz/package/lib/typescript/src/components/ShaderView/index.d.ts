import type { ShaderViewProps } from './types';
export default function ShaderView({ fragmentShader, colors, speed, params, isStatic, transparent, paramsSynchronizable, style, ...viewProps }: ShaderViewProps): import("react").JSX.Element;
//# sourceMappingURL=index.d.ts.map