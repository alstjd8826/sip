import type { ViewProps } from 'react-native';
import type { ColorInput } from '../utils/colors';
type Props = ViewProps & {
    /** Base tint color for the aurora effect. */
    color?: ColorInput;
    /** Animation speed multiplier. Default: 1.0 */
    speed?: number;
    /** Brightness of the aurora bands. Default: 1.0 */
    intensity?: number;
    /** Number of aurora curtain layers (1-5). Default: 3 */
    layers?: number;
    /** How wavy/turbulent the curtains are. Default: 1.0 */
    waviness?: number;
};
export default function Aurora({ color, speed, intensity, layers, waviness, ...viewProps }: Props): import("react").JSX.Element;
export {};
//# sourceMappingURL=Aurora.d.ts.map