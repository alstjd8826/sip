import type { ViewProps } from 'react-native';
import type { ColorInput } from '../utils/colors';
type Props = ViewProps & {
    /** The color tint for the iridescence effect. */
    color?: ColorInput;
    /** Animation speed multiplier. Default: 1.0 */
    speed?: number;
};
export default function Iridescence({ color, speed, ...viewProps }: Props): import("react").JSX.Element;
export {};
//# sourceMappingURL=Iridescence.d.ts.map