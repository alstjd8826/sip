/**
 * Lazily requests a single GPUDevice shared by every ShaderView.
 *
 * Requesting an adapter + device per view is expensive (real GPU/memory cost and
 * slower init), and a screen that mounts several effects would otherwise spin up
 * N devices on the one background runtime. The promise is cached for the lifetime
 * of the JS runtime so every view awaits the same device.
 *
 * If the device is ever lost, the cache is cleared so the next ShaderView mount
 * requests a fresh one instead of awaiting a dead device forever.
 */
export declare function getSharedGPUDevice(): Promise<GPUDevice | null>;
//# sourceMappingURL=gpuDevice.d.ts.map