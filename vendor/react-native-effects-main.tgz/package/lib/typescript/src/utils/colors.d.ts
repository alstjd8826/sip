export type ColorInput = number | string;
/**
 * RGBA color values normalized to 0-1 range
 */
export type RGBA = {
    r: number;
    g: number;
    b: number;
    a: number;
};
/**
 * Converts various color formats to RGBA object
 * @param color - Can be:
 *   - Hex number (0xff0000)
 *   - Hex string ("#ff0000" or "ff0000")
 *   - RGB string ("rgb(255, 0, 0)")
 *   - RGBA string ("rgba(255, 0, 0, 0.5)")
 *   - Named color ("red", "blue", "purple", etc.)
 * @returns RGBA object with normalized values (0-1), alpha defaults to 1.0 for non-rgba formats
 */
export declare function colorToVec4(color: ColorInput): RGBA;
//# sourceMappingURL=colors.d.ts.map