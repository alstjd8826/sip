export declare const BackgroundRuntime: import("react-native-worklets").WorkletRuntime;
export declare function runOnBackground(callback: (...args: any[]) => void): void;
//# sourceMappingURL=backgroundRuntime.d.ts.map